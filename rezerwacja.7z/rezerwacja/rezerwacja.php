<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "baza";

// Tworzenie połączenia
$conn = new mysqli($servername, $username, $password, $dbname);

// Sprawdzanie połączenia
if ($conn->connect_error) {
    die("Połączenie nieudane: " . $conn->connect_error);
}

// Pobieranie danych z formularza
$data = $_POST['data'];
$ilosc_osob = $_POST['ilosc_osob'];
$telefon = $_POST['telefon'];

// Przygotowanie i wykonanie zapytania
$sql = "INSERT INTO rezerwacje (data, ilosc_osob, telefon) VALUES ('$data', '$ilosc_osob', '$telefon')";
if ($conn->query($sql) === TRUE) {
    echo "Dodano rezerwację do bazy";
} else {
    echo "Błąd: " . $sql . "<br>" . $conn->error;
}

// Zamykanie połączenia
$conn->close();
?>
